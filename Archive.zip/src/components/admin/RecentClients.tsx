"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRightIcon, EyeIcon } from "@heroicons/react/24/outline";
import { db } from "@/lib/firebase";
import { usePaginatedQuery } from "@/hooks/usePaginatedQuery";
import { MealPlanStatus } from "@/types/status";
import EmptyState from "./EmptyState";
import { UsersIcon } from "@heroicons/react/24/outline";
import ClientDetailSlideover from "./ClientDetailSlideover";

type RecentClient = {
  id: string;
  name: string;
  email: string;
  packageTier: string | null;
  mealPlanStatus: string;
  createdAt?: Date | null;
};

export default function RecentClients() {
  const [selectedClient, setSelectedClient] = useState<any | null>(null);
  const [slideoverOpen, setSlideoverOpen] = useState(false);

  // Memoize filter function to prevent re-renders
  const filterNonAdmins = useMemo(
    () => (doc: any) => doc.role !== "admin",
    []
  );

  const {
    data: rawClients,
    loading,
    refresh,
  } = usePaginatedQuery<any>({
    db,
    collectionName: "users",
    pageSize: 5, // Only show 5 most recent
    orderByField: "createdAt",
    orderByDirection: "desc",
    filterFn: filterNonAdmins,
  });

  // Transform and get recent clients
  const recentClients = useMemo(() => {
    return rawClients.slice(0, 5).map((client: any) => {
      let createdAt: Date | null = null;
      if (client.createdAt) {
        if (client.createdAt.toDate) {
          createdAt = client.createdAt.toDate();
        } else if (client.createdAt instanceof Date) {
          createdAt = client.createdAt;
        }
      }

      return {
        id: client.id,
        name: client.displayName ?? "Unnamed User",
        email: client.email ?? "No email",
        packageTier: client.packageTier ?? null,
        mealPlanStatus: client.mealPlanStatus ?? MealPlanStatus.NOT_STARTED,
        createdAt,
      } as RecentClient;
    });
  }, [rawClients]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case MealPlanStatus.DELIVERED:
        return "bg-green-500/20 text-green-400 border-green-500/30";
      case MealPlanStatus.IN_PROGRESS:
        return "bg-amber-500/20 text-amber-400 border-amber-500/30";
      default:
        return "bg-neutral-600/20 text-neutral-400 border-neutral-600/30";
    }
  };

  if (loading) {
    return (
      <div className="rounded-2xl border border-neutral-800/50 bg-gradient-to-br from-neutral-900 to-neutral-950 p-6 shadow-xl">
        <div className="h-6 w-32 animate-pulse rounded bg-neutral-800 mb-4" />
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-16 animate-pulse rounded-lg bg-neutral-800/50" />
          ))}
        </div>
      </div>
    );
  }

  if (recentClients.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-neutral-800/50 bg-gradient-to-br from-neutral-900 to-neutral-950 p-6 shadow-xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-white font-display">Recent Clients</h3>
          <Link
            href="/admin/clients"
            className="text-sm font-semibold text-[#D7263D] hover:text-[#D7263D]/80 transition-colors"
          >
            View all
          </Link>
        </div>
        <EmptyState
          icon={<UsersIcon className="h-12 w-12" />}
          title="No clients yet"
          description="New clients will appear here once they register."
          className="rounded-xl border-0 m-0 p-8"
        />
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-neutral-800/50 bg-gradient-to-br from-neutral-900 to-neutral-950 p-6 shadow-xl"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-white font-display">Recent Clients</h3>
        <Link
          href="/admin/clients"
          className="flex items-center gap-1 text-sm font-semibold text-[#D7263D] hover:text-[#D7263D]/80 transition-colors group"
        >
          View all
          <ArrowRightIcon className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>
      <div className="space-y-3">
        {recentClients.map((client, index) => (
          <motion.div
            key={client.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ x: 4 }}
            className="flex items-center justify-between p-4 rounded-xl border border-neutral-800/50 bg-neutral-800/20 hover:bg-neutral-800/40 hover:border-neutral-700 transition-all duration-200 group cursor-pointer"
          >
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-1.5">
                <p className="text-sm font-semibold text-white truncate group-hover:text-[#D7263D] transition-colors">
                  {client.name}
                </p>
                <span
                  className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-bold flex-shrink-0 ${getStatusColor(
                    client.mealPlanStatus
                  )}`}
                >
                  {client.mealPlanStatus}
                </span>
              </div>
              <p className="text-xs text-neutral-400 truncate">
                {client.email}
              </p>
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setSelectedClient(client);
                setSlideoverOpen(true);
              }}
              className="ml-4 p-2 rounded-lg border border-neutral-700 bg-neutral-800/50 hover:bg-[#D7263D] hover:border-[#D7263D] transition-all duration-200 flex-shrink-0 group"
            >
              <EyeIcon className="h-4 w-4 text-neutral-300 group-hover:text-white transition-colors" />
            </motion.button>
          </motion.div>
        ))}
      </div>

      {/* Client Detail Slideover */}
      <ClientDetailSlideover
        client={selectedClient}
        isOpen={slideoverOpen}
        onClose={() => {
          setSlideoverOpen(false);
          setSelectedClient(null);
        }}
        onUpdate={refresh}
      />
    </motion.div>
  );
}
