export { default as DashboardCardSkeleton } from "./DashboardCardSkeleton";
export { default as ProfileSkeleton } from "./ProfileSkeleton";
export { default as AdminTableSkeleton } from "./AdminTableSkeleton";
export { default as PackageListSkeleton } from "./PackageListSkeleton";
export { default as MealPlanSkeleton } from "./MealPlanSkeleton";

