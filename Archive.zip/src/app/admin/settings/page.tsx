"use client";

import { SettingsPage } from "@/components/admin/settings";

export default function AdminSettingsPage() {
  return <SettingsPage />;
}
