export const PRICE_IDS = {
  Basic: "price_1SRV5LC9GeeSL2vBXBlL7sUP",
  Pro: "price_1SRV5qC9GeeSL2vBM49Fqb4H",
  Elite: "price_1SRV6GC9GeeSL2vBLaRFkKKf",
} as const;

